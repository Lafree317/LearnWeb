# Gallery-by-React

根据慕课网mater Liu老师的教程，自己修改为最新node和webpack版本，修改为ES6语法的一个css3动画画廊项目

##使用方式

clone后运行npm install(推荐使用淘宝镜像cnpm，会快很多)，然后npm start
然后访问[http://localhost:8080/#/]我们就可以看到项目跑起来了。

##框架介绍
采用yeoman生成脚手架,运用了webpack+React+ES6+SASS.
图片及文字信息在src/data/imageData.json

##待解决问题
在ie内核浏览器里面，图片翻转后不显示背面文字信息，而是为图片的镜像

##待改进及加入功能
带加入图片及文字信息存入mongodb，增加入口可以上传图片和加入描述的功能（React_on_Rails）
后续搭建ES6 + react + redux +immutable + isomorphic + react-router + react-thunk + react-test + nodejs + mongodb框架